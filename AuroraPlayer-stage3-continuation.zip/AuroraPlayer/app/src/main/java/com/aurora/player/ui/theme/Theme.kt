package com.aurora.player.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.aurora.player.domain.model.AppSettings
import com.aurora.player.domain.model.ThemeMode

/** Accent choices offered in Settings (Stage 5). ARGB. */
val AccentPalette: List<Int> = listOf(
    0xFF7C5CFFL, 0xFF00C2A8L, 0xFFFF5C8AL, 0xFFFFB020L, 0xFF3D9BFFL, 0xFF8BE04EL,
).map { it.toInt() }

private fun darkScheme(accent: Color, amoled: Boolean): ColorScheme {
    val bg = if (amoled) Color.Black else Color(0xFF121214)
    val surface = if (amoled) Color(0xFF0B0B0D) else Color(0xFF1A1A1D)
    return darkColorScheme(
        primary = accent,
        onPrimary = if (accent.luminance() > 0.5f) Color.Black else Color.White,
        primaryContainer = accent.copy(alpha = 0.22f).compositeOver(bg),
        onPrimaryContainer = Color.White,
        secondary = accent,
        background = bg,
        onBackground = Color(0xFFF2F2F5),
        surface = surface,
        onSurface = Color(0xFFF2F2F5),
        surfaceVariant = Color(0xFF1C1C21),
        onSurfaceVariant = Color(0xFFA9A9B3),
        surfaceContainer = surface,
        surfaceContainerHigh = Color(0xFF16161A),
        outline = Color(0xFF3A3A42),
    )
}

private fun lightScheme(accent: Color): ColorScheme = lightColorScheme(
    primary = accent,
    onPrimary = if (accent.luminance() > 0.5f) Color.Black else Color.White,
    primaryContainer = accent.copy(alpha = 0.16f).compositeOver(Color.White),
    secondary = accent,
    background = Color(0xFFFAFAFC),
    surface = Color.White,
    surfaceVariant = Color(0xFFEDEDF2),
)

@Composable
fun AuroraTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val accent = Color(settings.accentColor)
    val scheme = if (dark) darkScheme(accent, settings.amoled) else lightScheme(accent)

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(colorScheme = scheme, typography = AuroraTypography, content = content)
}
