package com.aurora.player

import android.app.Application
import android.content.Context
import com.aurora.player.data.local.AppDatabase
import com.aurora.player.data.prefs.SettingsRepository
import com.aurora.player.data.repository.LibraryRepository

/** Manual DI container: fewer moving parts than Hilt, same testability for an app this size. */
class AppContainer(context: Context) {
    val database: AppDatabase by lazy { AppDatabase.create(context) }
    val settingsRepository: SettingsRepository = SettingsRepository(context.applicationContext)
    val libraryRepository: LibraryRepository by lazy { LibraryRepository(context.contentResolver, database) }
}

class MusicApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
