package com.aurora.player.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PlaylistEntity::class, PlaylistSongEntity::class, FavoriteEntity::class,
        PlayHistoryEntity::class, ExcludedFolderEntity::class, LyricsEntity::class, QueueItemEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun historyDao(): HistoryDao
    abstract fun excludedFolderDao(): ExcludedFolderDao
    abstract fun lyricsDao(): LyricsDao
    abstract fun queueDao(): QueueDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "aurora.db").build()
    }
}
