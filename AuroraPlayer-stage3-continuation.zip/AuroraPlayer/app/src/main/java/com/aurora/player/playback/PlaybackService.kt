package com.aurora.player.playback

import android.content.ContentUris
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.aurora.player.MusicApp
import com.aurora.player.data.local.PlayHistoryEntity
import com.aurora.player.domain.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            setHandleAudioBecomingNoisy(true)
            repeatMode = Player.REPEAT_MODE_OFF
            addListener(object : Player.Listener {
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    val id = mediaItem?.mediaId?.toLongOrNull() ?: return
                    serviceScope.launch {
                        (application as MusicApp).container.database.historyDao()
                            .insert(PlayHistoryEntity(songId = id, playedAt = System.currentTimeMillis()))
                    }
                }
                override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
                    if (reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED) persistQueue()
                }
            })
        }
        mediaSession = MediaSession.Builder(this, player).build()
        restoreQueue()
    }

    private fun persistQueue() {
        val ids = (0 until player.mediaItemCount).mapNotNull { player.getMediaItemAt(it).mediaId.toLongOrNull() }
        serviceScope.launch { (application as MusicApp).container.database.queueDao().replaceAll(ids) }
    }

    private fun restoreQueue() {
        serviceScope.launch {
            val ids = (application as MusicApp).container.database.queueDao().getAll()
            if (ids.isEmpty()) return@launch
            val items = ids.map { id ->
                val uri = ContentUris.withAppendedId(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                MediaItem.Builder().setMediaId(id.toString()).setUri(uri)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle("Audio $id").build()).build()
            }
            withContext(Dispatchers.Main) { if (player.mediaItemCount == 0) player.setMediaItems(items) }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.release()
        player.release()
        mediaSession = null
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        fun mediaItem(song: Song): MediaItem = MediaItem.Builder()
            .setMediaId(song.id.toString()).setUri(Uri.parse(song.contentUri))
            .setMediaMetadata(MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist)
                .setAlbumTitle(song.album).setArtworkUri(song.artworkUri?.let(Uri::parse)).build()).build()
    }
}
