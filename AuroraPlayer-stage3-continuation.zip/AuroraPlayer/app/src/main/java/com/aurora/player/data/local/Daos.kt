package com.aurora.player.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

data class PlaylistSummary(val id: Long, val name: String, val songCount: Int)

@Dao
interface PlaylistDao {
    @Insert suspend fun insert(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name, updatedAt = :now WHERE id = :id")
    suspend fun rename(id: Long, name: String, now: Long)

    @Query("DELETE FROM playlists WHERE id = :id") suspend fun delete(id: Long)

    @Query(
        "SELECT p.id AS id, p.name AS name, " +
            "(SELECT COUNT(*) FROM playlist_songs WHERE playlistId = p.id) AS songCount " +
            "FROM playlists p ORDER BY p.name COLLATE NOCASE"
    )
    fun observeSummaries(): Flow<List<PlaylistSummary>>

    @Query("SELECT songId FROM playlist_songs WHERE playlistId = :playlistId ORDER BY position")
    fun observeSongIds(playlistId: Long): Flow<List<Long>>

    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun nextPosition(playlistId: Long): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addSong(entry: PlaylistSongEntity): Long

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removeSong(playlistId: Long, songId: Long)

    @Query("UPDATE playlist_songs SET position = :position WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun setPosition(playlistId: Long, songId: Long, position: Int)
}

@Dao
interface FavoriteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun add(fav: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE songId = :songId") suspend fun remove(songId: Long)
    @Query("SELECT songId FROM favorites ORDER BY addedAt DESC") fun observeIds(): Flow<List<Long>>
}

@Dao
interface HistoryDao {
    @Insert suspend fun insert(entry: PlayHistoryEntity)

    @Query("SELECT songId FROM play_history GROUP BY songId ORDER BY MAX(playedAt) DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<Long>>

    @Query("SELECT songId FROM play_history GROUP BY songId ORDER BY COUNT(*) DESC, MAX(playedAt) DESC LIMIT :limit")
    fun observeMostPlayed(limit: Int): Flow<List<Long>>

    @Query(
        "SELECT songId FROM play_history WHERE playedAt > :since " +
            "GROUP BY songId HAVING COUNT(*) >= 3 ORDER BY COUNT(*) DESC LIMIT :limit"
    )
    fun observeFrequent(since: Long, limit: Int): Flow<List<Long>>

    @Query("DELETE FROM play_history") suspend fun clear()
}

@Dao
interface ExcludedFolderDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun add(folder: ExcludedFolderEntity)
    @Query("DELETE FROM excluded_folders WHERE path = :path") suspend fun remove(path: String)
    @Query("SELECT path FROM excluded_folders ORDER BY path") fun observePaths(): Flow<List<String>>
}

@Dao
interface LyricsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(lyrics: LyricsEntity)
    @Query("SELECT * FROM lyrics WHERE songId = :songId") fun observe(songId: Long): Flow<LyricsEntity?>
    @Query("DELETE FROM lyrics WHERE songId = :songId") suspend fun delete(songId: Long)
}

@Dao
abstract class QueueDao {
    @Query("SELECT songId FROM queue_items ORDER BY position") abstract suspend fun getAll(): List<Long>
    @Insert abstract suspend fun insertAll(items: List<QueueItemEntity>)
    @Query("DELETE FROM queue_items") abstract suspend fun clear()

    @Transaction
    open suspend fun replaceAll(songIds: List<Long>) {
        clear()
        insertAll(songIds.mapIndexed { i, id -> QueueItemEntity(i, id) })
    }
}
