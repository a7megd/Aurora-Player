package com.aurora.player.domain.model

enum class RepeatMode { OFF, ALL, ONE }
enum class ThemeMode { SYSTEM, DARK, LIGHT }
enum class SongSort { TITLE, ARTIST, ALBUM, DATE_ADDED, DURATION }

/** A local audio file. [id] is the MediaStore _ID and is the key used by every Room table. */
data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val path: String,
    val folderPath: String,
    val mimeType: String,
    val sizeBytes: Long,
    val year: Int,
    val trackNumber: Int,
    val dateAddedSec: Long,
    val contentUri: String,
    val artworkUri: String?,
)

data class Album(val id: Long, val title: String, val artist: String, val songCount: Int, val artworkUri: String?)
data class Artist(val name: String, val songCount: Int, val albumCount: Int)
data class Folder(val path: String, val name: String, val songCount: Int)

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val amoled: Boolean = true,
    val accentColor: Int = 0xFF7C5CFF.toInt(),
    val songSort: SongSort = SongSort.TITLE,
    val songSortAscending: Boolean = true,
)
