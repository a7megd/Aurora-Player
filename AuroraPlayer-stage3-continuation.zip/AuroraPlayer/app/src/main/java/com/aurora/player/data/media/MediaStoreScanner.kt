package com.aurora.player.data.media

import android.content.ContentResolver
import android.content.ContentUris
import android.provider.MediaStore
import com.aurora.player.domain.model.Song
import java.io.File

/** Reads the device audio index. MediaStore IDs remain the stable keys used by Room. */
class MediaStoreScanner(private val resolver: ContentResolver) {
    fun scan(): List<Song> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.DATE_ADDED,
        )
        val result = mutableListOf<Song>()
        resolver.query(
            collection, projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 0",
            null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val yearCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val path = cursor.getString(pathCol).orEmpty()
                val albumId = cursor.getLong(albumIdCol)
                val contentUri = ContentUris.withAppendedId(collection, id).toString()
                result += Song(
                    id = id,
                    title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: File(path).nameWithoutExtension,
                    artist = cursor.getString(artistCol)?.takeUnless { it == "<unknown>" }.orEmpty().ifBlank { "Unknown artist" },
                    album = cursor.getString(albumCol)?.takeUnless { it == "<unknown>" }.orEmpty().ifBlank { "Unknown album" },
                    albumId = albumId,
                    durationMs = cursor.getLong(durationCol),
                    path = path,
                    folderPath = File(path).parent.orEmpty(),
                    mimeType = cursor.getString(mimeCol).orEmpty(),
                    sizeBytes = cursor.getLong(sizeCol),
                    year = if (cursor.isNull(yearCol)) 0 else cursor.getInt(yearCol),
                    trackNumber = cursor.getInt(trackCol),
                    dateAddedSec = cursor.getLong(dateCol),
                    contentUri = contentUri,
                    artworkUri = if (albumId > 0) "content://media/external/audio/albumart/$albumId" else null,
                )
            }
        }
        return result
    }
}
