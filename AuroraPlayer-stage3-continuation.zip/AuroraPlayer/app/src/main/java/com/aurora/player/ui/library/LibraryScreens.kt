package com.aurora.player.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.aurora.player.domain.model.Album
import com.aurora.player.domain.model.Artist
import com.aurora.player.domain.model.Folder
import com.aurora.player.domain.model.Song

@Composable
fun LibraryScreen(
    title: String,
    songs: List<Song>,
    albums: List<Album>,
    artists: List<Artist>,
    folders: List<Folder>,
    excludedFolders: List<String>,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onRefresh: () -> Unit,
    onExcludeFolder: (String) -> Unit,
    onIncludeFolder: (String) -> Unit,
    onSongClick: (Song) -> Unit,
    onPlayAll: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.headlineMedium)
                Text(
                    when (title) {
                        "Songs" -> "${songs.size} tracks"
                        "Albums" -> "${albums.size} albums"
                        "Artists" -> "${artists.size} artists"
                        else -> "${folders.size} folders"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (title == "Songs" && songs.isNotEmpty()) TextButton(onClick = onPlayAll) { Text("Play all") }
                TextButton(onClick = onRefresh, enabled = hasPermission) { Text("Refresh") }
            }
        }
        if (!hasPermission) {
            EmptyLibrary(
                title = "Your music library is waiting",
                message = "Allow Aurora Player to access audio files stored on this device. Your music stays on your phone.",
                action = "Grant access",
                onAction = onRequestPermission,
            )
        } else {
            when (title) {
                "Songs" -> if (songs.isEmpty()) EmptyLibrary("No songs found", "Add audio files to your device, then refresh the library.", null, {})
                    else LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(songs, key = { it.id }) { SongRow(it, onSongClick) }
                    }
                "Albums" -> if (albums.isEmpty()) EmptyLibrary("No albums found", "Albums will appear here when audio is indexed.", null, {})
                    else LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(albums, key = { it.id }) { album -> AlbumRow(album) }
                    }
                "Artists" -> if (artists.isEmpty()) EmptyLibrary("No artists found", "Artist names will appear here when audio is indexed.", null, {})
                    else LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(artists, key = { it.name }) { artist -> ArtistRow(artist) }
                    }
                else -> if (folders.isEmpty() && excludedFolders.isEmpty()) EmptyLibrary("No folders found", "Folders containing indexed music will appear here.", null, {})
                    else LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(folders, key = { it.path }) { folder -> FolderRow(folder, onExcludeFolder) }
                        if (excludedFolders.isNotEmpty()) {
                            item { Text("Excluded folders", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 8.dp, top = 18.dp)) }
                            items(excludedFolders, key = { "excluded:$it" }) { path ->
                                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(path.substringAfterLast('/').ifBlank { path }, style = MaterialTheme.typography.titleSmall)
                                        Text(path, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    IconButton(onClick = { onIncludeFolder(path) }) { Icon(Icons.Rounded.Restore, contentDescription = "Restore folder") }
                                }
                            }
                        }
                    }
            }
        }
    }
}

@Composable
private fun EmptyLibrary(title: String, message: String, action: String?, onAction: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.AudioFile, null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text(title, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (action != null) {
                Spacer(Modifier.height(18.dp))
                Button(onClick = onAction) { Text(action) }
            }
        }
    }
}

@Composable
private fun SongRow(song: Song, onClick: (Song) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onClick(song) }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AsyncImage(model = song.artworkUri, contentDescription = null, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
            Text("${song.artist}  •  ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(formatDuration(song.durationMs), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AlbumRow(album: Album) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = album.artworkUri, contentDescription = null, modifier = Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(album.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(album.artist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${album.songCount} songs", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Rounded.Album, null, tint = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun ArtistRow(artist: Artist) {
    LibraryTextRow(Icons.Rounded.Person, artist.name, "${artist.albumCount} albums  •  ${artist.songCount} songs")
}

@Composable
private fun FolderRow(folder: Folder, onExclude: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) { LibraryTextRow(Icons.Rounded.Folder, folder.name, "${folder.songCount} songs", folder.path) }
        IconButton(onClick = { onExclude(folder.path) }) { Icon(Icons.Rounded.Block, contentDescription = "Exclude folder") }
    }
}

@Composable
private fun LibraryTextRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, detail: String? = null) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, modifier = Modifier.size(42.dp).padding(8.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (detail != null) Text(detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun formatDuration(ms: Long): String {
    val total = ms.coerceAtLeast(0) / 1000
    return "%d:%02d".format(total / 60, total % 60)
}
