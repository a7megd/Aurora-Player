package com.aurora.player.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.aurora.player.domain.model.AppSettings
import com.aurora.player.domain.model.SongSort
import com.aurora.player.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsStore by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_mode")
        val AMOLED = booleanPreferencesKey("amoled")
        val ACCENT = intPreferencesKey("accent")
        val SORT = stringPreferencesKey("song_sort")
        val SORT_ASC = booleanPreferencesKey("song_sort_asc")
    }

    val settings: Flow<AppSettings> = context.settingsStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val d = AppSettings()
            AppSettings(
                themeMode = p[Keys.THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: d.themeMode,
                amoled = p[Keys.AMOLED] ?: d.amoled,
                accentColor = p[Keys.ACCENT] ?: d.accentColor,
                songSort = p[Keys.SORT]?.let { runCatching { SongSort.valueOf(it) }.getOrNull() } ?: d.songSort,
                songSortAscending = p[Keys.SORT_ASC] ?: d.songSortAscending,
            )
        }

    suspend fun setThemeMode(mode: ThemeMode) { context.settingsStore.edit { it[Keys.THEME] = mode.name } }
    suspend fun setAmoled(enabled: Boolean) { context.settingsStore.edit { it[Keys.AMOLED] = enabled } }
    suspend fun setAccent(argb: Int) { context.settingsStore.edit { it[Keys.ACCENT] = argb } }
    suspend fun setSort(sort: SongSort, ascending: Boolean) {
        context.settingsStore.edit {
            it[Keys.SORT] = sort.name
            it[Keys.SORT_ASC] = ascending
        }
    }
}
