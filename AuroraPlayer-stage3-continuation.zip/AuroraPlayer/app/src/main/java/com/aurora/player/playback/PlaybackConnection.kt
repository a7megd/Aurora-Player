package com.aurora.player.playback

import android.content.ComponentName
import android.content.Context
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.aurora.player.domain.model.Song
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executor

class PlaybackConnection(context: Context) {
    private val appContext = context.applicationContext
    private val mainExecutor: Executor = appContext.mainExecutor
    private val token = SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
    private val future: ListenableFuture<MediaController> = MediaController.Builder(appContext, token).buildAsync()
    private val _controller = MutableStateFlow<MediaController?>(null)
    val controller = _controller.asStateFlow()

    init {
        future.addListener({ runCatching { _controller.value = future.get() } }, mainExecutor)
    }

    fun playQueue(songs: List<Song>, startIndex: Int = 0) {
        val c = _controller.value ?: return
        if (songs.isEmpty()) return
        c.setMediaItems(songs.map(PlaybackService::mediaItem), startIndex.coerceIn(songs.indices), 0L)
        c.prepare()
        c.play()
    }

    fun play(song: Song, library: List<Song>) {
        val index = library.indexOfFirst { it.id == song.id }
        playQueue(if (index >= 0) library else listOf(song), if (index >= 0) index else 0)
    }

    fun release() {
        MediaController.releaseFuture(future)
        _controller.value = null
    }
}
