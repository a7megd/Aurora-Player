# Aurora Player - progress log

## Stage 1 - Architecture + Foundation
Completed in the supplied archive: Gradle/KSP/version catalog, manifest foundation, design system (dark/AMOLED/light + accent), DataStore settings, Room entities/DAOs, domain models, manual DI container, and navigation shell.

## Stage 2 - Device library
Implemented in this drop:
- MediaStore audio scanner using MediaStore `_ID` as the song identity and content URIs for playback-ready references.
- Audio metadata mapping: title, artist, album, duration, file/folder path, MIME type, size, year, track, date added, and album artwork URI.
- Library repository with a MediaStore ContentObserver, background refresh, and excluded-folder filtering backed by Room.
- Album, artist, and folder grouping derived from the scanned song list.
- Runtime audio permission request (`READ_MEDIA_AUDIO` on Android 13+, `READ_EXTERNAL_STORAGE` on Android 8-12).
- Functional Songs, Albums, Artists, and Folders library views with empty/permission states and manual refresh.
- AppContainer wiring for the library repository.

Not included yet: playback, mini-player, queue controls, playlist management UI, folder exclusion controls in the UI, search, favorites/recents screens, equalizer, and settings UI. These remain in later stages unless explicitly pulled forward.

## Validation status
Source files were reviewed and archive structure checked. This environment does not contain an Android SDK and the supplied archive has no `gradle-wrapper.jar`; therefore no APK build, emulator run, or device playback test has been performed. Open the project in Android Studio with network access to resolve the pinned Gradle/dependencies, then compile and test on a device.

## Next
Stage 3: Media3 `MediaSessionService`, controller connection, queue persistence/resume, audio focus, noisy-audio handling, notification, and mini-player.

## Stage 3 - Playback foundation (continued in this workspace)
Implemented in the current continuation:
- Media3 ExoPlayer hosted by a `MediaSessionService`, with media-session notification integration.
- Audio focus handling through Media3 audio attributes and pause-on-headphone-disconnect behavior.
- Song metadata and content-URI mapping into Media3 media items.
- Tap-to-play and Play All from the Songs library, plus a compact play/pause/next mini-player.
- Room-backed playback history and queue ID persistence; the last queue is restored when the service starts.

Validation remains pending: this environment has Java but no Android SDK, Gradle executable, Gradle wrapper JAR, or network access. The new Kotlin sources have not been compiled or run on a device. Stage 3 is therefore source-implemented, not build-verified.
